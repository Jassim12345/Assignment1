#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

//struct GasType to hold the name and price for each gas type
struct GasType {
    string name;
    float price;
};
// procedure to display the gas types and prices to the customer so he can choose what he wants
void displayGasTypesAndPrices(GasType gasTypes[], int size) {
    cout << "--------------------------------------Welcome to Gas 4 Taxes--------------------------------------" << endl;
    cout << "|                            Gas Type               |              Price            |" << endl;
    cout << "--------------------------------------------------------------------------------------------------" << endl;
    for (int i = 0; i < size; ++i) {
        cout << "|   " << setw(33) << gasTypes[i].name <<setw(19)<< "   |   " << fixed << setprecision(2)<<setw(12) <<"$"<< gasTypes[i].price<<setw(13) << "   |" << endl;
    }
    cout << "--------------------------------------------------------------------------------------------------" << endl;
}

// function to calculate the total price the customer should pay by multiplying the quantity of the gas chosen by the price per gallon of this gas
float calculateTotal(float gallons, float price) {
    return gallons * price;
}

// function to calculate the total price after adding the taxes
float applySalesTax(float total) {
    return total * (1 + 0.095); // 0.095 like the one used in group exercise 4 on Piazza
}

int main() {
    // define variables and an array 
    int GasTypesNB = 4;
    GasType gasTypes[GasTypesNB] = { {"Regular", 5.02}, {"Midgrade", 5.22}, {"Premium", 5.42}, {"Diesel", 6.03} };

    displayGasTypesAndPrices(gasTypes, GasTypesNB);

    string gasType;
    float gallons;
    string paymentMethod;
    float total;
    
    cout << "Choose a gas type to fill up your car: ";
    cin >> gasType;
    cout << "How many gallons: ";
    cin >> gallons;

// if else statements to calculate total price based on the gas chosen by the customer and its quantity
    if(gasType == "Regular")
       total = calculateTotal(gallons,gasTypes[0].price);
       else if(gasType == "Midgrade")
       total = calculateTotal(gallons,gasTypes[1].price);
       else if(gasType == "Premium")
       total = calculateTotal(gallons,gasTypes[2].price);
       else if(gasType == "Diesel")
       total = calculateTotal(gallons,gasTypes[3].price);

// displaying the total and the total with tax price to the customer 
    cout << "Your total is $" << fixed << setprecision(2) << total << endl;
    float totalWithTax = applySalesTax(total);
    cout << "Your total with tax is $" << fixed << setprecision(2) << totalWithTax << endl;
    
// asking the customer about the way he wanna pay using it
    cout << "How would you like to pay for it? (Debit Card, Credit Card, Gift Card or Cash): ";
    getline(cin >>ws,paymentMethod);

    cout << "Great! You have paid the balance of $" << fixed << setprecision(2) << totalWithTax << " using your " << paymentMethod << "." << endl;
    cout << "Thank you for filling up gas at Gas 4 Taxes, a place to get broke!" << endl;

    return 0;
}

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;


struct Menu {
    string name;
    float price;
};

// procedure to display the menu to the customer (Meals and Deserts)
void displayMenu(Menu menu[], int size, const string& category) {
    cout << "|                 " << category << "                      |                   Price            |" << endl;
    cout << "****************************************************************************" << endl;
    for (int i = 0; i < size; ++i) {
        cout << "|   " << setw(33) << menu[i].name <<setw(13)<< "   |   " << fixed << setprecision(2)<<setw(12) <<"$"<< menu[i].price<<setw(16) << "   |" << endl;
    }
}  

// function to calculate the taxes after calculating the total 
float applySalesTax(float total) {
    return total * (1 + 0.095); 
}

int main() {
    // define variables and 2 arrays
    int size = 4;
    Menu meals[size] = { {"Discovery Bay Burger (B)", 15.00}, {"GRILLED CHICKEN SANDWICH (S)", 16.00}, {"TURKEY, BACON & AVOCADO (T)", 15.00}, {"FISH & CHIPS (F) ", 16.00} };
    Menu deserts[size] = { {"Pie (P)", 9.00}, {"Chocolate Ice Cream (I)", 8.00}, {"Tiramisu (T)", 10.00}, {"Brownies (B)", 11.00} };
    
      cout << "*********Welcome to Discovery Bay Golf and Country Club Restaurant******** "<< endl;
    displayMenu(meals,size, "Meal");
    cout<<endl;
    displayMenu(deserts,size, "Desert");
    cout<<endl;

    string meal;
    string desert;
    
    
    cout << "Enter a Meal that you would like to order:";
    cin >> meal;
    cout << "Enter a Desert that you would like to order:";
    cin >> desert;
    

 float subtotal = 0;
 
 // if else statements to calculate subtotal based on the chosen meal and desert 
      if(meal == "B")
       subtotal=15.00;
       else if(meal == "S")
        subtotal=16.00;
       else if(meal == "T")
         subtotal=15.00;
       else if(meal == "F")
         subtotal=16.00;
         
    if(desert == "P")
       subtotal+=9.00;
       else if(desert == "I")
        subtotal+=8.00;
       else if(desert == "T")
         subtotal+=10.00;
       else if(desert == "B")
         subtotal+=11.00;
         

    float salesTax = applySalesTax(subtotal);
    
// displaying the total and the total with tax price to the customer 
    cout << "Your total is $" << fixed << setprecision(2) << subtotal << " and this will go to member charge!" << endl;
     cout << "Your total with taxes is: $" << fixed << setprecision(2) << salesTax << endl;
    cout << "Thank you for dining with us at Discovery Bay Golf and Country Club! You made Matt Padilla happy ?" << endl;

    return 0;

}
